import numpy as np
import subprocess
from math import sqrt
from sklearn.metrics import average_precision_score
from scipy import stats
import random
import torch
import os
from tqdm import tqdm

device = torch.device('cuda:0')

def calculate_metrics_and_return(Y, P, dataset='kiba'):
    # aupr = get_aupr(Y, P)
    # cindex = get_cindex(Y, P)  # DeepDTA
    cindex = get_ci(Y, P)
    rm2 = get_rm2(Y, P)  # DeepDTA
    mse = get_mse(Y, P)
    pearson = get_pearson(Y, P)
    spearman = get_spearman(Y, P)

    print('metrics for ', dataset)
    # print('aupr:', aupr)
    print('cindex:', cindex)

    print('rm2:', rm2)
    print('mse:', mse)
    print('pearson:', pearson)
    print('spearman:', spearman)
    return cindex,rm2,mse, pearson, spearman

def train(model, train_loader, optimizer, epoch):
    print('Training on {} samples...'.format(len(train_loader.dataset)))
    model.train()

    loss_fn = torch.nn.MSELoss()
    l = 0
    cl = 0
    for batch_idx, data in enumerate(tqdm(train_loader)):
        data = [data.to(device) for data in data]
        data, stru_d, stru_p = data
        optimizer.zero_grad()
        output, cl_loss = model(data, stru_d, stru_p)
        loss = loss_fn(output.float(), data.y.float().to(device)).float()
        l = l + loss.item()
        cl = cl + cl_loss.item()
        loss = cl_loss + loss
        loss.backward()
        optimizer.step()
    print('Train loss: {}'.format(l))
    print('Train cl_loss: {}'.format(cl))
def predicting(model, loader):
    model.eval()
    total_preds = torch.Tensor()
    total_labels = torch.Tensor()
    print('Make prediction for {} samples...'.format(len(loader.dataset)))
    with torch.no_grad():
        for data in loader:
            data = [data.to(device) for data in data]
            data, stru_d, stru_p = data
            # data = data.to(device)
            output, _ = model(data, stru_d, stru_p)
            total_preds = torch.cat((total_preds, output.cpu()), 0)
            total_labels = torch.cat((total_labels, data.y.view(-1, 1).cpu()), 0)
    return total_labels.numpy().flatten(), total_preds.numpy().flatten()


def get_ci(y,f):
    ind = np.argsort(y)
    y = y[ind]
    f = f[ind]
    i = len(y)-1
    j = i-1
    z = 0.0
    S = 0.0
    while i > 0:
        while j >= 0:
            if y[i] > y[j]:
                z = z+1
                u = f[i] - f[j]
                if u > 0:
                    S = S + 1
                elif u == 0:
                    S = S + 0.5
            j = j - 1
        i = i - 1
        j = i-1
    ci = S/z
    return ci

def get_mse(y, f):
    mse = ((y - f) ** 2).mean(axis=0)
    return mse

def seed_torch(seed=0):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
atom_dict = {5: 'C',
             6: 'C',
             9: 'O',
             12: 'N',
             15: 'N',
             21: 'F',
             23: 'S',
             25: 'Cl',
             26: 'S',
             28: 'O',
             34: 'Br',
             36: 'P',
             37: 'I',
             39: 'Na',
             40: 'B',
             41: 'Si',
             42: 'Se',
             44: 'K',
             }



def get_aupr(Y, P, threshold=7.0):
    # print(Y.shape,P.shape)
    Y = np.where(Y >= 7.0, 1, 0)
    P = np.where(P >= 7.0, 1, 0)
    aupr = average_precision_score(Y, P)
    return aupr


def get_cindex(Y, P):
    summ = 0
    pair = 0

    for i in range(1, len(Y)):
        for j in range(0, i):
            if i != j:
                if (Y[i] > Y[j]):
                    pair += 1
                    summ += 1 * (P[i] > P[j]) + 0.5 * (P[i] == P[j])

    if pair != 0:
        return summ / pair
    else:
        return 0


def r_squared_error(y_obs, y_pred):
    y_obs = np.array(y_obs)
    y_pred = np.array(y_pred)
    y_obs_mean = [np.mean(y_obs) for y in y_obs]
    y_pred_mean = [np.mean(y_pred) for y in y_pred]

    mult = sum((y_pred - y_pred_mean) * (y_obs - y_obs_mean))
    mult = mult * mult

    y_obs_sq = sum((y_obs - y_obs_mean) * (y_obs - y_obs_mean))
    y_pred_sq = sum((y_pred - y_pred_mean) * (y_pred - y_pred_mean))

    return mult / float(y_obs_sq * y_pred_sq)


def get_k(y_obs, y_pred):
    y_obs = np.array(y_obs)
    y_pred = np.array(y_pred)

    return sum(y_obs * y_pred) / float(sum(y_pred * y_pred))


def squared_error_zero(y_obs, y_pred):
    k = get_k(y_obs, y_pred)

    y_obs = np.array(y_obs)
    y_pred = np.array(y_pred)
    y_obs_mean = [np.mean(y_obs) for y in y_obs]
    upp = sum((y_obs - (k * y_pred)) * (y_obs - (k * y_pred)))
    down = sum((y_obs - y_obs_mean) * (y_obs - y_obs_mean))

    return 1 - (upp / float(down))


def get_rm2(ys_orig, ys_line):
    r2 = r_squared_error(ys_orig, ys_line)
    r02 = squared_error_zero(ys_orig, ys_line)

    return r2 * (1 - np.sqrt(np.absolute((r2 * r2) - (r02 * r02))))


def get_rmse(y, f):
    rmse = sqrt(((y - f) ** 2).mean(axis=0))
    return rmse


def get_mse(y, f):
    mse = ((y - f) ** 2).mean(axis=0)
    return mse


def get_pearson(y, f):
    rp = np.corrcoef(y, f)[0, 1]
    return rp


def get_spearman(y, f):
    rs = stats.spearmanr(y, f)[0]
    return rs


def calculate_metrics(Y, P, dataset='kiba'):
    # aupr = get_aupr(Y, P)
    cindex = get_cindex(Y, P)  # DeepDTA
    rm2 = get_rm2(Y, P)  # DeepDTA
    mse = get_mse(Y, P)
    pearson = get_pearson(Y, P)
    spearman = get_spearman(Y, P)
    rmse = get_rmse(Y, P)

    print('metrics for ', dataset)
    # print('aupr:', aupr)
    print('cindex:', cindex)

    print('rm2:', rm2)
    print('mse:', mse)
    print('pearson', pearson)
    print('spearman',spearman)


import plotly.express as px
import pandas as pd


def plot_interactive_heatmap(attention_matrix, protein_seq, drug_smiles, head_idx=None):
    """创建交互式注意力热图"""
    # 截取序列和矩阵
    max_protein_len = min(attention_matrix.shape[0], 200)
    max_drug_len = min(attention_matrix.shape[1], 50)
    att_matrix = attention_matrix[:max_protein_len, :max_drug_len].cpu().numpy()
    protein_seq = protein_seq[:max_protein_len]
    drug_smiles = drug_smiles[:max_drug_len]

    # 创建数据框
    df = pd.DataFrame(att_matrix,
                      index=[f"{i}:{aa}" for i, aa in enumerate(protein_seq)],
                      columns=[f"{i}:{char}" for i, char in enumerate(drug_smiles)])

    # 创建交互式热图
    fig = px.imshow(df, color_continuous_scale='viridis',
                    title=f"Attention Heatmap (Head {head_idx})" if head_idx else "Attention Heatmap",
                    labels=dict(x="Drug SMILES", y="Protein Sequence", color="Attention Score"))

    # 设置悬停信息
    fig.update_layout(width=1000, height=800)
    return fig
